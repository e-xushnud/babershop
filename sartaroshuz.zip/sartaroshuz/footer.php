<footer class="footer-area">
        <div class="container">
            <div class="row justify-content-between">
                <div class="col-xl-4 col-sm-6 col-lg-4">
                    <div class="single-footer-widget footer_1">
                        <h4>Biz haqimizda</h4>
                        <p>Bundan ham muvaffaqiyatli bo'lishni xohlaysizmi? O'rganishni va o'sishni yaxshi ko'rishni o'rganing. O'z mahoratingizni oshirishga qancha ko'p harakat qilsangiz, shuncha ko'p pul ishlaysiz. Bu narsalarni tushunib oling</p>
                        <p class="mt-3" >O'z mahoratingizni oshirishga qancha ko'p harakat qilsangiz, stil hozir katta bo'ladi </p>
                    </div>
                </div>
                <div class="col-xl-3 col-sm-6 col-lg-4">
                    <div class="single-footer-widget footer_2">
                        <h4>Biz bilan bog'lanish</h4>
                        <div class="contact_info">
                            <span class="ti-home"></span>
                            <h5>Samarqand viloyati Ishtixon tumani</h5>
                            <p>Ishtixon tumani 707-uy</p>
                        </div>
                        <div class="contact_info">
                            <span class="fa fa-phone"></span>
                            <h5>+998975777728</h5>
                            <p>Xohlagan vaqti murojaat qilishingiz mumkin!</p>
                        </div>
                    </div>
                </div>
                
                <div class="col-xl-4 col-sm-8 col-lg-4">
                    <div class="single-footer-widget footer_3">
                        <h4>So'ngiYangiliklar</h4>
                        <p>Bizning so'nggi tendentsiyalarimiz bilan doimo xabardor bo'lib turing O'z mahoratingizni oshirishga qancha ko'p harakat qilsangiz, shuncha ko'p pul ishlaysiz.</p>
                        <div class="form-wrap" id="mc_embed_signup">
                            <form target="_blank"
                                action="https://spondonit.us12.list-manage.com/subscribe/post?u=1462626880ade1ac87bd9c93a&amp;id=92a4423d01"
                                method="get" class="form-inline">
                                <input class="form-control" name="EMAIL" placeholder="Email adresingiz"
                                    onfocus="this.placeholder = ''" onblur="this.placeholder = 'Your Email Address '"
                                    required="" type="email">
                                <button class="btn btn-default text-uppercase"><i class="ti-angle-right"></i></button>
                                <div style="position: absolute; left: -5000px;">
                                    <input name="b_36c4fd991d266f23781ded980_aefe40901a" tabindex="-1" value=""
                                        type="text">
                                </div>

                                <div class="info"></div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="copyright_part">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12 text-center">
                        <p class="footer-text m-0"><!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
Mualliflik Huquqi &copy;<script>document.write(new Date().getFullYear());</script> Khushnud Eshtemirov
</p>
                    </div>
                </div>
            </div>
        </div>
    </footer>